const movingNav = document.querySelector(".nav-container");

window.addEventListener("scroll", enableMovingNav => {
    if(window.scrollY > 420){
        movingNav.style.animation = "fade-in-nav 3s ease-in-out";
        setTimeout(pause => {
            movingNav.style.opacity = "1";
        }, 500)
    }
    else{
        movingNav.style.animation = "fade-out-nav 3s ease-in-out";
        setTimeout(pause => {
            movingNav.style.opacity = "0";
        }, 500)
    }
});
